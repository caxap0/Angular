import { Component } from '@angular/core';

@Component({
  selector: 'app-about-course',
  imports: [],
  templateUrl: './about-course.component.html',
  styleUrl: './about-course.component.scss'
})
export class AboutCourseComponent {

}
