import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {CourseCardComponent} from '../course-card/course-card.component';

@Component({
  selector: 'app-home-page',
  imports: [CourseCardComponent],
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.scss'
})
export class HomePageComponent {
  constructor(private router: Router) {}

  navigateToAbout() {
    this.router.navigate(['/about'])
}
  navigateToCertificate() {
    this.router.navigate(['/certificate'])
  }
}
