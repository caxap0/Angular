import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { AboutCourseComponent } from './about-course/about-course.component';
import { CertificateComponent } from './certificate/certificate.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { CourseCardComponent } from './course-card/course-card.component';

const routes: Routes = [
  {path: '',component: HomePageComponent},
  {path: 'about', component: AboutCourseComponent},
  {path: 'certificate', component: CertificateComponent},
  {path: '**', component: PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
