import { Routes } from '@angular/router';
import { HomePageComponent} from './home-page/home-page.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AboutCourseComponent } from './about-course/about-course.component';
import { CertificateComponent } from './certificate/certificate.component';
import { CourseCardComponent } from './course-card/course-card.component';

export const routes: Routes = [
  {path: '',component: HomePageComponent},
  {path: 'about', component: AboutCourseComponent},
  {path: 'certificate', component: CertificateComponent},
  {path: '**', component: PageNotFoundComponent}
];
